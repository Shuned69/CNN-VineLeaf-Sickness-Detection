import requests
from utils.dictionary import code_dictionary
import dateutil.parser

MON_TOKEN = "7fb2ad3af724acb80042dfe08a2e438810f87a4c02b8083ce510c51f595ea6fe"


# FIND THE WEATHER CORRESPONDING THE VALUE
def search_weather_description(weather):
    if weather in code_dictionary:
        print(u"\tLe temps sera : " + code_dictionary[weather])


# GET THE CITY FROM USER
print("Entrez la ville dont vous voulez connaitre la meteo en indiquant son pays : Paris, France, Londres,uk...")
ville = input("De quelle ville voulez vous connaitre la meteo ? ")

# GET THE WEATHER DATA
url_weather = "https://api.meteo-concept.com/api/forecast/daily?token=" + MON_TOKEN + "&insee=" + ville

r_weather = requests.get(url_weather)
data = r_weather.json()

# RETURN WEATHER INFO ABOUT THE CITY REQUIRED
(city, forecast) = (data[k] for k in ('city', 'forecast'))
for i, f in enumerate(forecast):
    day = dateutil.parser.parse(f['datetime']).weekday()  # Lundi : 0, Mardi : 1, etc.

    weatherCode = str(f['weather'])
    search_weather_description(weatherCode)

print("Vous etes a " + data['city']['name'])

